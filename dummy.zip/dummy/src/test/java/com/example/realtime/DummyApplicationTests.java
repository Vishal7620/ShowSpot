package com.example.realtime;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DummyApplicationTests {

	@Test
	void contextLoads() {
	}

}
