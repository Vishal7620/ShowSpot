package com.example.realtime.controller;

import java.security.KeyStore.Entry;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.realtime.entities.Bookings;
import com.example.realtime.entities.Movies;
import com.example.realtime.entities.Seats;
import com.example.realtime.entities.TheaterTimmings;
import com.example.realtime.entities.Theaters;
import com.example.realtime.entities.seats_layout;
import com.example.realtime.repositories.BookingRepository;
import com.example.realtime.repositories.SeatsRepositories;
import com.example.realtime.services.MoviesService;
import com.example.realtime.services.SeatLayoutService;
import com.example.realtime.services.SeatsService;
import com.example.realtime.services.TheaterService;
import com.example.realtime.services.TheaterTimmingServices;

@RestController
public class MoviesController {

	@Autowired
	private MoviesService moviesService;
	@Autowired
	private TheaterService theaterService;

	@Autowired
	private SeatLayoutService seatLayoutService;
	
	@Autowired
	private SeatsService seatsService;
	
	@Autowired
	private BookingRepository bookingsRepository;
	
	@Autowired
	private TheaterTimmingServices theaterTimmingServices;
	
	@RequestMapping(value="/views/selectedMovie", method=RequestMethod.POST)
	 public ModelAndView handleCitySubmission(@RequestParam("city") String city)
	 {
		 ModelAndView modelandView=new ModelAndView();
	
		 try
		 {
		 List<Movies>movies=moviesService.getAllMoviesByLocation(city);
		 
		 modelandView.addObject("movies",movies);
		 modelandView.addObject("selectedCity",city);
		 modelandView.setViewName("homeCityWise");
		 }
		 catch(Exception e)
		 {
			 modelandView.setViewName("error");
			 e.printStackTrace();
		 }
		 return modelandView;
	 }
	
	@GetMapping("/views/selectedMovie")
	public ModelAndView getMovie(@RequestParam("movieId")long id)
	{
		ModelAndView modelandView=new ModelAndView();
	
		try
		{
		Movies movie=moviesService.getMoviesById(id);
        modelandView.setViewName("error");
		
		SimpleDateFormat dateFormat=new SimpleDateFormat("dd MMM yyyy");
		String formattedDate=movie.getReleaseDate()!=null ? dateFormat.format(movie.getReleaseDate()):" ";
		
	    modelandView.addObject("formattedDate",formattedDate);
	    modelandView.addObject("movie",movie);
		
	    modelandView.setViewName("selectedMovie");
		}
		catch (Exception e) {
			// TODO: handle exception
		modelandView.setViewName("error");
		}
	    return modelandView;
	}
	
	
	
	@GetMapping("/views/selectTheater")
	public ModelAndView bookTickets(@RequestParam("movieId")long movieId,@RequestParam("city")String city)
	{
		ModelAndView modelandView =new ModelAndView();
		try
		{
			//for movies
		Movies movie=moviesService.getMoviesById(movieId);
		modelandView.addObject("movie",movie);
		modelandView.addObject("city",city);
		
		//for theater- timming data fetching start
		
		List<Theaters>theaters=theaterService.findTheatersByCity(city);
		
		
		
		for(Theaters t:theaters)
		{
			System.out.println(t.getTheaterName());
		}
		
		Map<String,List<String>> map=new HashMap<>();
		SimpleDateFormat dateFormat=new SimpleDateFormat("HH:mm");
		
		for(Theaters theater:theaters)
		{
			   String theaterName = theater.getTheaterName();
	            String formattedDate = theater.getMovieTimings() != null ? dateFormat.format(theater.getMovieTimings()) : " ";

	            // Get the list associated with the current theaterId, or create a new list if it doesn't exist
	            List<String> timings = map.computeIfAbsent(theaterName, k -> new ArrayList<>());
	            timings.add(formattedDate);
		}
	
		
		Set<String>dummySet=new LinkedHashSet<>();
		List<Long>id=new ArrayList<>();
		for(Theaters theater:theaters)
		{
			dummySet.add(theater.getTheaterName());
			id.add(theater.getTheaterId());
		}
		
		Set<Theaters> newUpdatedTheater=new LinkedHashSet<>();
		int i=0;
		for(String str:dummySet)
		{
			Theaters t=new Theaters();
			t=theaterService.getTheaterByTheaterNameAndId(str, id.get(i));
			newUpdatedTheater.add(t);
			++i;
		}
		
		for(Long t:id)
		{
			System.out.println(t);
		}
		
		modelandView.addObject("theaters",newUpdatedTheater);
		
	    modelandView.addObject("theater-timing",map);
		 
	    modelandView.addObject("theaterId",id);
	    
	    //theater theater timming data fetching
		
		modelandView.setViewName("selectTheater");
		}
		catch (Exception e) {
			// TODO: handle exception
			modelandView.setViewName("error");
			e.printStackTrace();
		}
		return modelandView;
	}
	
	@GetMapping("/views/seatLayout")
	public ModelAndView selectTimmingsToproceed(@RequestParam("movieId")long movieId,@RequestParam("city")String city,
			@RequestParam("theaterId")Long theaterId,@RequestParam("timming")String timming,@RequestParam("date")String formatteddate1)
	{
		ModelAndView modelAndView=new ModelAndView();
		
		try
		{
			Theaters theater=theaterService.findTheaterById(theaterId);
			
			Movies movie=moviesService.getMoviesById(movieId);
			
			List<seats_layout> listOfSeatLayout=seatLayoutService.findLayoutByLayoutName(theater.getLayout());
			
			List<Seats>seatList=seatsService.findSeatsByLayout(theater.getLayout());
			
			modelAndView.addObject("date",formatteddate1);
			modelAndView.addObject("timming",timming);
			modelAndView.addObject("movie",movie);
			modelAndView.addObject("theater",theater);
			
			modelAndView.addObject("listOfSeatLayout",listOfSeatLayout);
			
			modelAndView.addObject("seatList",seatList);
			
		    modelAndView.setViewName("seatLayout");
		}
		catch (Exception e) {
			// TODO: handle exception
			
			e.printStackTrace();
			modelAndView.setViewName("error");
		}
		return modelAndView;
	}
	@PostMapping("/bookingSummary")
	public ModelAndView handleBookings(@RequestParam("selectedSeats")String selectedSeats,
			                           @RequestParam("movieId")Long movieId,
			                           @RequestParam("theaterId")Long theaterId)
	{
		ModelAndView modelAndView =new ModelAndView();
		try
		{
			String[] seatIds=selectedSeats.split(",");
			Movies movie=moviesService.getMoviesById(movieId);
			Theaters theater=theaterService.findTheaterById(theaterId);
			modelAndView.addObject("seatIds",seatIds);
			
			List<Seats>bookedSeats=new ArrayList<>();
			for(String seatid:seatIds)
			{
				Seats seat=new Seats();
				Long temp=Long.parseLong(seatid);
				seat=seatsService.findSeatsById(temp);
				bookedSeats.add(seat);
			}
			
			modelAndView.addObject("bookedSeats",bookedSeats);
			modelAndView.addObject("movieId",movie);
			modelAndView.addObject("theaterId",theater);
			modelAndView.setViewName("bookingSummary");
			
		}
		catch (Exception e) {
			// TODO: handle exception
			
			e.printStackTrace();
			modelAndView.setViewName("error");
		}
		
		
		return modelAndView;
	}
	

	@PostMapping("/payment")
	public ModelAndView showPaymentPage(@RequestParam("bookedSeats") String bookedSeats,
			                            @RequestParam("movieId")Long movieId,@RequestParam("theaterId")Long thetaerId,
			                            @RequestParam("subTotal")int subTotal) {
	    ModelAndView modelAndView = new ModelAndView("payment");

	    // Split seat numbers by comma and trim any extra spaces
	    List<String> seatNumbers = Arrays.asList(bookedSeats.split(","));
         
	    Movies movies=moviesService.getMoviesById(movieId);
	    Theaters theater=theaterService.findTheaterById(thetaerId);
	    
	    // Fetch seat objects using their IDs
	    List<Seats> seatsList = seatNumbers.stream()
	        .map(seatNumber -> {
	            try {
	                return seatsService.findSeatsById(Long.parseLong(seatNumber.trim()));
	            } catch (NumberFormatException e) {
	                // Handle potential errors
	                return null;
	            }
	        })
	        .filter(Objects::nonNull) // Avoid adding null values to the list
	        .collect(Collectors.toList());
        
	    modelAndView.addObject("movieId",movies);
	    modelAndView.addObject("theaterId",theater);
	    modelAndView.addObject("subTotal",subTotal);
	    modelAndView.addObject("bookedSeats", seatsList);

	    return modelAndView;
	}

	@PostMapping("/submitPayment")
	public ModelAndView addDetails(@RequestParam("bookedSeatIds")List<Long> bookedSeatsIds,
			                       @RequestParam("fullName")String fullName,
			                       @RequestParam("amount")String amount,
			                       @RequestParam("email")String mail,
			                       @RequestParam("contact")String contact,
			                       @RequestParam("movieId")Long movieId,
			                       @RequestParam("theaterId")Long theaterId)
	{
		
		ModelAndView modelandView=new ModelAndView();
		try
		{
			Movies movie=moviesService.getMoviesById(movieId);
			Theaters theater=theaterService.findTheaterById(theaterId);
			Bookings bookings=new Bookings();
			bookings.setFullName(fullName);
			bookings.setEmail(mail);
			bookings.setMovieId(movieId);
			bookings.setTheaterId(theaterId);
			bookings.setAmount(Long.parseLong(amount));
			bookingsRepository.save(bookings);
			modelandView.addObject("bookings",bookings);
			modelandView.addObject("movie",movie);
			modelandView.addObject("theater",theater);
			modelandView.addObject("amount",amount);
			modelandView.setViewName("success");
		}
		catch (Exception e) {
			// TODO: handle exception
			
			e.printStackTrace();
			modelandView.setViewName("error");
		}
		
		return modelandView;
	}
	
}
