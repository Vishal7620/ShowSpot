package com.example.realtime.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.realtime.entities.Bookings;

@Repository
public interface BookingRepository extends JpaRepository<Bookings, Long>{

}
