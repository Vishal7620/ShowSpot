<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Booking Success</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }
        .success-container {
            margin-top: 100px;
            text-align: center;
        }
        .emoji {
            font-size: 4rem;
        }
        .confirmation-message {
            font-size: 1.5rem;
            margin: 20px 0;
        }
        .btn-middle {
            margin-top: 30px;
            text-align: center;
        }
    </style>
</head>
<body>

 <div class="container success-container">
        <!-- Success Emoji and Message -->
        <div class="row">
            <div class="col-md-12">
                <span class="emoji">🎉🎟️</span>
                <h1 class="confirmation-message">Seats Booked Successfully!</h1>
                <p>Your booking is confirmed! We hope you enjoy your movie 🎬🍿</p>
            </div>
        </div>

        <!-- Booking Details -->
        <div class="row">
            <div class="col-md-12">
                <p><strong>Movie:</strong> <%= movieName %></p>
                <p><strong>Theater:</strong> <%= theaterName %></p>
                <p><strong>Seats:</strong> <%= seatNumbers %></p>
                <p><strong>Amount Paid:</strong> ₹<%= amountPaid %></p>
            </div>
        </div>

        <!-- Button in the Middle -->
        <div class="row btn-middle">
            <div class="col-md-12">
                <a href="/home" class="btn btn-primary btn-lg">Go to Home 🏠</a>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>